import SwiftUI

// MARK: - Home View
struct HomeView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Welcome Section
                VStack(alignment: .leading, spacing: 8) {
                    Text("Chào mừng trở lại!")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                    
                    Text("Hãy tiếp tục hành trình học AI của bạn")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 20)
                
                // Progress Overview
                VStack(alignment: .leading, spacing: 12) {
                    Text("Tiến Độ Của Bạn")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                    
                    HStack(spacing: 20) {
                        ProgressCircleView(
                            progress: appState.userProgress.totalProgress,
                            size: 100,
                            lineWidth: 8
                        )
                        
                        VStack(alignment: .leading, spacing: 8) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Mô-đun đã hoàn thành")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                Text("\(appState.userProgress.completedModules)/\(appState.userProgress.totalModules)")
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(.primaryBlue)
                            }
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Tổng điểm")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                Text("\(appState.userProgress.totalPoints)")
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(.accentOrange)
                            }
                        }
                        
                        Spacer()
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
                
                // Current Module
                if let currentModule = appState.modules.first(where: { $0.status == .current }) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Tiếp Tục Học")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundColor(.black)
                        
                        ModuleCardView(module: currentModule)
                        
                        PrimaryButton(title: "Tiếp tục học") {
                            appState.selectedTab = .learning
                        }
                    }
                }
                
                // Quick Actions
                VStack(alignment: .leading, spacing: 12) {
                    Text("Hành Động Nhanh")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                    
                    HStack(spacing: 12) {
                        QuickActionCard(
                            icon: "book.fill",
                            title: "Học ngay",
                            color: .primaryBlue
                        ) {
                            appState.selectedTab = .learning
                        }
                        
                        QuickActionCard(
                            icon: "flask.fill",
                            title: "Thực hành",
                            color: .accentOrange
                        ) {
                            appState.selectedTab = .practice
                        }
                        
                        QuickActionCard(
                            icon: "chart.bar.fill",
                            title: "Tiến độ",
                            color: .successGreen
                        ) {
                            appState.selectedTab = .progress
                        }
                    }
                }
                
                Spacer(minLength: 100)
            }
            .padding(.horizontal, 20)
        }
        .background(Color.backgroundGray)
    }
}

struct QuickActionCard: View {
    let icon: String
    let title: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(color)
                
                Text(title)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.black)
            }
            .frame(maxWidth: .infinity, minHeight: 80)
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Learning Path View
struct LearningPathView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header
                VStack(alignment: .leading, spacing: 6) {
                    Text("Lộ Trình Học")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 20)
                
                // Modules
                VStack(spacing: 16) {
                    ForEach(appState.modules) { module in
                        ModuleCardView(module: module)
                    }
                }
                
                Spacer(minLength: 100)
            }
            .padding(.horizontal, 20)
        }
        .background(Color.backgroundGray)
    }
}

// MARK: - Practice Lab View
struct PracticeLabView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header
                VStack(alignment: .leading, spacing: 6) {
                    Text("Phòng Thực Hành")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 20)
                
                // Coming Soon
                VStack(spacing: 16) {
                    Image(systemName: "flask")
                        .font(.system(size: 60))
                        .foregroundColor(.accentOrange)
                    
                    Text("Phòng thực hành sắp ra mắt!")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                    
                    Text("Bạn sẽ có thể thực hành các kỹ năng AI với các bài tập tương tác.")
                        .font(.body)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(40)
                .background(Color.white)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
                
                Spacer(minLength: 100)
            }
            .padding(.horizontal, 20)
        }
        .background(Color.backgroundGray)
    }
}

// MARK: - Profile View
struct ProfileView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header
                VStack(alignment: .leading, spacing: 6) {
                    Text("Hồ Sơ")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 20)
                
                // Profile Info
                VStack(spacing: 16) {
                    Image(systemName: "person.circle.fill")
                        .font(.system(size: 80))
                        .foregroundColor(.primaryBlue)
                    
                    Text("Phong Han")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                    
                    Text("Học viên EnergyAI")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity)
                .padding(20)
                .background(Color.white)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
                
                // Stats Grid
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 12) {
                    StatCard(title: "Điểm số", value: "\(appState.userProgress.totalPoints)", icon: "star.fill", color: .accentOrange)
                    StatCard(title: "Chuỗi ngày", value: "\(appState.userProgress.streakDays)", icon: "flame.fill", color: .errorRed)
                    StatCard(title: "Mô-đun", value: "\(appState.userProgress.completedModules)/\(appState.userProgress.totalModules)", icon: "book.fill", color: .primaryBlue)
                    StatCard(title: "Thành tựu", value: "\(appState.achievements.filter { $0.isEarned }.count)", icon: "trophy.fill", color: .successGreen)
                }
                
                Spacer(minLength: 100)
            }
            .padding(.horizontal, 20)
        }
        .background(Color.backgroundGray)
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
            
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.black)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, minHeight: 100)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
    }
}