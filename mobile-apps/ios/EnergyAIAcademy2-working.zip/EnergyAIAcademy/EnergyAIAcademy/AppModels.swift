import SwiftUI
import Foundation

// MARK: - Models
struct Module: Identifiable, Codable {
    let id: Int
    let title: String
    let duration: TimeInterval
    let microlessons: [Microlesson]
    let status: ModuleStatus
    let progress: Double
    let icon: String
    let unlockRequirement: String?
}

enum ModuleStatus: String, CaseIterable, Codable {
    case completed = "completed"
    case current = "current"
    case locked = "locked"
}

struct Microlesson: Identifiable, Codable {
    let id: String
    let title: String
    let duration: TimeInterval
    let points: Int
    let status: MicrolessonStatus
}

enum MicrolessonStatus: String, CaseIterable, Codable {
    case completed = "completed"
    case current = "current"
    case locked = "locked"
}

struct UserProgress: Codable {
    var totalProgress: Double = 0.65
    var completedModules: Int = 1
    var totalModules: Int = 5
    var streakDays: Int = 7
    var totalPoints: Int = 1250
}

struct Achievement: Identifiable, Codable {
    let id: String
    let title: String
    let description: String
    let icon: String
    let isEarned: Bool
    let points: Int
}

struct LeaderboardEntry: Identifiable {
    let id: String
    let username: String
    let points: Int
    let rank: Int
    let isCurrentUser: Bool
    let positionChange: PositionChange
}

enum PositionChange {
    case winner
    case up
    case down
    case same
}

// MARK: - Sample Data
let sampleModules: [Module] = [
    Module(
        id: 1,
        title: "Mô-đun 1: AI Cơ Bản & Ứng Dụng Năng Lượng",
        duration: 2520,
        microlessons: [
            Microlesson(id: "1.1", title: "Giới thiệu khóa học & mục tiêu", duration: 420, points: 50, status: .completed),
            Microlesson(id: "1.2", title: "Trí tuệ nhân tạo - Nền tảng", duration: 420, points: 50, status: .completed),
            Microlesson(id: "1.3", title: "Machine Learning - Máy học", duration: 420, points: 50, status: .completed),
            Microlesson(id: "1.4", title: "Generative AI - AI sáng tạo", duration: 420, points: 50, status: .completed),
            Microlesson(id: "1.5", title: "Ứng dụng trong ngành năng lượng", duration: 420, points: 50, status: .completed),
            Microlesson(id: "1.6", title: "Kiểm tra kiến thức", duration: 420, points: 100, status: .completed)
        ],
        status: .completed,
        progress: 1.0,
        icon: "✅",
        unlockRequirement: nil
    ),
    Module(
        id: 2,
        title: "Mô-đun 2: Hiểu Về Mô Hình Ngôn Ngữ Lớn",
        duration: 2520,
        microlessons: [
            Microlesson(id: "2.1", title: "Mô hình ngôn ngữ lớn là gì?", duration: 420, points: 50, status: .completed),
            Microlesson(id: "2.2", title: "Xử lý thông tin (Tokens & Parameters)", duration: 420, points: 50, status: .completed),
            Microlesson(id: "2.3", title: "Kiến trúc Transformer", duration: 420, points: 50, status: .current),
            Microlesson(id: "2.4", title: "Ứng dụng LLM trong năng lượng", duration: 420, points: 50, status: .locked),
            Microlesson(id: "2.5", title: "Hạn chế & lưu ý", duration: 420, points: 50, status: .locked),
            Microlesson(id: "2.6", title: "Kiểm tra kiến thức", duration: 420, points: 100, status: .locked)
        ],
        status: .current,
        progress: 0.33,
        icon: "📚",
        unlockRequirement: nil
    ),
    Module(
        id: 3,
        title: "Mô-đun 3: AI Chatbot Trong Công Việc Năng Lượng",
        duration: 2520,
        microlessons: [],
        status: .locked,
        progress: 0.0,
        icon: "🔒",
        unlockRequirement: "Hoàn thành Mô-đun 2"
    ),
    Module(
        id: 4,
        title: "Mô-đun 4: Làm Chủ Kỹ Thuật Prompt",
        duration: 2520,
        microlessons: [],
        status: .locked,
        progress: 0.0,
        icon: "🔒",
        unlockRequirement: "Hoàn thành Mô-đun 3"
    ),
    Module(
        id: 5,
        title: "Mô-đun 5: Đạo Đức & Thực Hành Tốt Nhất",
        duration: 2520,
        microlessons: [],
        status: .locked,
        progress: 0.0,
        icon: "🔒",
        unlockRequirement: "Hoàn thành Mô-đun 4"
    )
]

let sampleAchievements: [Achievement] = [
    Achievement(id: "first_lesson", title: "Bài đầu tiên", description: "Hoàn thành bài học đầu tiên", icon: "🎯", isEarned: true, points: 50),
    Achievement(id: "week_streak", title: "Tuần liên tiếp", description: "Học 7 ngày liên tiếp", icon: "🔥", isEarned: true, points: 100),
    Achievement(id: "module_complete", title: "Hoàn thành mô-đun", description: "Hoàn thành mô-đun đầu tiên", icon: "🏆", isEarned: true, points: 200),
    Achievement(id: "ai_expert", title: "Chuyên gia AI", description: "Đạt 90% trở lên tất cả bài kiểm tra", icon: "🧠", isEarned: false, points: 500),
    Achievement(id: "practice_master", title: "Thạc sĩ thực hành", description: "Hoàn thành 50 bài tập thực hành", icon: "⚡", isEarned: false, points: 300),
    Achievement(id: "community_helper", title: "Trợ giúp cộng đồng", description: "Giúp đỡ 10 người học khác", icon: "🤝", isEarned: false, points: 150)
]

let sampleLeaderboard: [LeaderboardEntry] = [
    LeaderboardEntry(id: "1", username: "Phong Han", points: 1250, rank: 1, isCurrentUser: true, positionChange: .winner),
    LeaderboardEntry(id: "2", username: "Minh Anh", points: 1180, rank: 2, isCurrentUser: false, positionChange: .up),
    LeaderboardEntry(id: "3", username: "Hoàng Long", points: 1050, rank: 3, isCurrentUser: false, positionChange: .down),
    LeaderboardEntry(id: "4", username: "Thu Hà", points: 980, rank: 4, isCurrentUser: false, positionChange: .same),
    LeaderboardEntry(id: "5", username: "Văn Đạt", points: 920, rank: 5, isCurrentUser: false, positionChange: .up)
]

// MARK: - App State
class AppState: ObservableObject {
    @Published var selectedTab: TabBarView.Tab = .home
    @Published var userProgress = UserProgress()
    @Published var modules: [Module] = []
    @Published var achievements: [Achievement] = []
    
    init() {
        loadInitialData()
    }
    
    private func loadInitialData() {
        modules = sampleModules
        achievements = sampleAchievements
    }
}