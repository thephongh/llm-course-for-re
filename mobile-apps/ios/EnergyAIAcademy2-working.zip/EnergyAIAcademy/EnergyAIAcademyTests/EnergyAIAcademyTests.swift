//
//  EnergyAIAcademyTests.swift
//  EnergyAIAcademyTests
//
//  Created by Phong Han on 7/2/25.
//

import Testing
@testable import EnergyAIAcademy

struct EnergyAIAcademyTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
